<div class="footer-wrap pd-20 mb-20 card-box">
    DeskApp - Bootstrap 4 Admin Template By
    <a href="https://github.com/dropways" target="_blank">Ankit Hingarajiya</a>
</div>